var status = 0;
var currentHint = 0;
var maxHint = parseInt(localStorage.getItem("maxHint" + 1));
var maxHintDisplay = maxHint;
localStorage.setItem("maxHint1", 3);
localStorage.setItem("maxHint2", 2);
localStorage.setItem("maxHint3", 5);
localStorage.setItem("sp_scorel1",0);
localStorage.setItem("sp_scorel2",0);
localStorage.setItem("sp_scorel3",0);
localStorage.setItem("sp_scorel4",0);
localStorage.setItem("sp_scorel5",0);
localStorage.setItem("sp_scorel6",0);
localStorage.setItem("sp_scorel7",0);
localStorage.setItem("sp_scorel8",0);
localStorage.setItem("sp_scorel9",0);
localStorage.setItem("sp_scorel10",0);
localStorage.setItem("sp_scorel11",0);
localStorage.setItem("sp_scorel12", 0);
localStorage.setItem("imagel1", "images/ursa.png"); //yes
localStorage.setItem("imagel2", "images/hydra.png");
localStorage.setItem("imagel3", "images/petitlion.png");// yes
localStorage.setItem("imagel4", "images/canisminor.png");
localStorage.setItem("imagel5", "images/gemini.png"); //yes
localStorage.setItem("imagel6", "images/taurus.png");
localStorage.setItem("imagel7", "images/aries.png");
localStorage.setItem("imagel8", "images/triangulum.png");// yes
localStorage.setItem("imagel9", "images/cassio.png"); //yes
localStorage.setItem("imagel10", "images/lyra.png"); //yes
localStorage.setItem("imagel11", "images/sagitta.png");//yes
localStorage.setItem("imagel12", "images/corona.png");
$(document).ready(function () {
    var level = parseInt(localStorage.getItem("levelupdate"));
    var valid = parseInt(localStorage.getItem("validnum"));
    maxHint = parseInt(localStorage.getItem("maxHint" + level));
    maxHintDisplay = maxHint;
    var coords = eval("coords" + level);
    for (i = 0; i < coords.length; i++) {
        css = {
            left: coords[i][0] - 6,
            top: coords[i][1] - 17,
            zIndex: coords.length - i
        }
        class_active = (i == 0) ? ' active' : '';
        var hiddenDot = -1;
        if (level == 1) {
            hiddenDot = 8;
        }
        else if (level == 2) {
            hiddenDot = 8;
        }
        else if (level == 3) {
            hiddenDot = 4;
        }
        if (i == hiddenDot) {
            div = $('<div id="dot_container_' + i + '" order_value="' + i + '" class="dot_container' + class_active + '"><div class ="dot1"><span id = "here" class = \"glyphicon glyphicon-star\" style = \"font-size:33px; color:black\"></span></div><div class="dot_number">' + (i + 1) + '</div></div>').css(css);
        }
        else {
            div = $('<div id="dot_container_' + i + '" order_value="' + i + '" class="dot_container' + class_active + '"><div class ="dot1"><span id = "here" class = \"glyphicon glyphicon-star\" style = \"font-size:33px; color:white\"></span></div><div class="dot_number" id="dot_number_' + i + '" style="visibility="visible">' + (i + 1) + '</div></div>').css(css);
        }
        MSApp.execUnsafeLocalFunction(function () {
            $('#canvas').append(div);
        });
    }
    $('.dot_container').click(function () {
        status = parseInt(status, 10) + 1;
        //MSApp.execUnsafeLocalFunction(function () {
            document.getElementById("here").style.color = "#FFD700";
        //});
        if ($(this).hasClass('active')) {
            var i = parseInt($(this).attr('order_value'));
            $(this).removeClass('active');
            if (i == 0) {
                $('div#dot_container_' + (i + 1)).addClass('active');
                return false;
            }
            x1 = coords[i - 1][0];
            y1 = coords[i - 1][1];
            x2 = coords[i][0];
            y2 = coords[i][1];
            var m = (y2 - y1) / (x2 - x1);
            var angle = (Math.atan(m)) * 180 / (Math.PI);
            var d = Math.sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)));
            var transform;
            if (x2 >= x1) {
                transform = (360 + angle) % 360;
            } else {
                transform = 180 + angle;
            }
            var id = 'line_' + new Date().getTime();
            var line = "<div id='" + id + "'class='line'>&nbsp;</div>";
            MSApp.execUnsafeLocalFunction(function () {
                $('#canvas').append(line);
            });
            $('#' + id).css({
                'left': x1,
                'top': y1,
                'width': '0px',
                'transform': 'rotate(' + transform + 'deg)',
                'transform-origin': '0px 0px',
                '-ms-transform': 'rotate(' + transform + 'deg)',
                '-ms-transform-origin': '0px 0px',
                '-moz-transform': 'rotate(' + transform + 'deg)',
                '-moz-transform-origin': '0px 0px',
                '-webkit-transform': 'rotate(' + transform + 'deg)',
                '-webkit-transform-origin': '0px 0px',
                '-o-transform': 'rotate(' + transform + 'deg)',
                '-o-transform-origin': '0px 0px'
            });
            $('#' + id).animate({
                width: d + 5,
            }, 350, "linear", function () {
                if (i < coords.length)
                    $('div#dot_container_' + (i + 1)).addClass('active');
            });

            if (i == valid) {
                stopCountDown();
                document.getElementById("btn").click();
            }
        }
    });
});
function showHint() {
    if (currentHint < maxHint) {
        document.getElementById("dot_container_" + status).click();
        maxHintDisplay--;
        document.getElementById('number').innerHTML = maxHintDisplay;
        currentHint++;
    }
    else {
        document.getElementById('hint').className += " disabled";
    }
}