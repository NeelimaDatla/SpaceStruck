﻿//localStorage.setItem("sp_l1score", 0);
function db_scores() {
    if (typeof (Storage) !== "undefined") {
        var l1 = parseInt(localStorage.getItem("levelupdate"));
        x = "sp_scorel" + l1;
        var score1 = parseInt(localStorage.getItem(x));
        // But it will be the same as file na , we will have the same problem again
        if (score > score1)
            localStorage.setItem(x, score);
        score1 = parseInt(localStorage.getItem(x));
        //alert(score1);
        //localStorage.setItem("sp_scorel2", 0);
       // localStorage.setItem("sp_scorel3", 0);
        //localStorage.setItem("sp_scorel4", 0);
        //localStorage.setItem("sp_scorel5", 0);
        //localStorage.setItem("l1time",ltime);
        var score1 = parseInt(localStorage.getItem(x));
        if (score1 == 10) {
            document.getElementById("scores").innerHTML = "<img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/> <img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/><img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/>";
        }
        else if (score1 == 6) {
            document.getElementById("scores").innerHTML = "<img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/> <img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/><img src=\"images/gold_star_hollow.png\" style=\"width: 50px; height: 50px;\"/>";
        }
        else if (score1 == 3) {
            document.getElementById("scores").innerHTML = "<img src=\"images/gold_star.png\" style=\"width: 50px; height: 50px;\"/> <img src=\"images/gold_star_hollow.png\" style=\"width: 50px; height: 50px;\"/><img src=\"images/gold_star_hollow.png\" style=\"width: 50px; height: 50px;\"/>";
        }
    }
    else {
        document.getElementById("scores").innerHTML = "Sorry, your browser does not support Web Storage...";
    }
}