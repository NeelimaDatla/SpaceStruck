﻿function level1_page() {
    window.location.assign("level1.html")

}
function homepage() {
    window.location.assign("default.html")

}
function level2_page() {
    window.location.assign("level2.html")

}
function level3_page() {
    window.location.assign("level3.html")

}
function level4_page() {
    window.location.assign("level4.html")

}
function game() {
        window.location.assign("game.html")

    }