﻿var flag = 0;
var score = 0;
var ltime = 0;
function stopCountDown() {
    var level_time = parseInt(localStorage.getItem("level_time"));
    var element2 = document.getElementById("status");
    var time = parseInt(element2.innerHTML);
    var new_time = level_time - time;
    var element4 = document.getElementById("time_tc");
    if (new_time > 0 && new_time <= 10) {
        score = 10;
    }
    else if (new_time > 10 && new_time <= 14) {
        score = 6;
    }
    else if (new_time > 14) {
        score = 3;
    }
    element4.innerHTML = "You have finished this level in" + " " + new_time + " " + "seconds";
    flag = 1;
    ltime = new_time;
    db_scores();
}